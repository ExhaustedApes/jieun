package com.example.a0411;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.jsoup.Jsoup;
import org.jsoup.select.Elements;
import org.jsoup.nodes.Document;
//import org.w3c.dom.Document;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    String url = "https://search.naver.com/search.naver?sm=tab_hty.top&where=nexearch&ssc=tab.nx.all&query=%EB%84%A4%EC%9D%B4%EB%B2%84%EB%82%A0%EC%94%A8&oquery=%EB%84%A4%EC%9D%B4%EB%B2%84%EB%82%A0%EC%94%A8&tqi=iCK7HdpzLiwsskkE6WossssstCw-276301";
    String weather, time;
    final Bundle bundle = new Bundle();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.weather);
        textView = (TextView) findViewById(R.id.time);

        final Bundle bundle = new Bundle();

        new Thread() {
            @Override
            public void run() {
                Document doc = null;
                try {
                    doc = Jsoup.connect(url).get();

                    // get weather through web crawling
                    Elements content1 = doc.select(".summary");
                    weather += content1.text();
                    String[] split_weather = weather.split(" ");
                    String now_weather = split_weather[3];

                    bundle.putString("now_weather", now_weather);
                    Message msg = handler.obtainMessage();
                    msg.setData(bundle);
                    handler.sendMessage(msg);

                    // get time through web crawling
                    Elements content2 = doc.select(".graph_content");
                    time += content2.text();



                    //Elements content2 = doc.select(".graph_inner _hourly_weather");
                    //doc.select(".graph_inner _hourly_weather");
                    //time += " " + content2.text();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    Handler handler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(@NonNull Message msg) {
            Bundle bundle = msg.getData();
            textView.setText(bundle.getString("now_weather"));
        }
    };



}